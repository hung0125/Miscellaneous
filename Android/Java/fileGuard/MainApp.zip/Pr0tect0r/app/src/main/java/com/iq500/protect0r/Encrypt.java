package com.iq500.protect0r;


import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.util.*;
public class Encrypt extends Activity 
{
	//parameters
	private Boolean isEncrypt = false;
	private String path = "";
	private int option = 0; 

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.filepage);

		Switch sw = findViewById(R.id.Switch_Method);
		final TextView t = findViewById(R.id.txt_method);
		final RadioButton[] rd = {
			findViewById(R.id.Rad_All),
			findViewById(R.id.Rad_Inc_Ext),
			findViewById(R.id.Rad_Exc_Ext),
			findViewById(R.id.Rad_Inc_Name),
			findViewById(R.id.Rad_Exc_Name)
		};
		final EditText cmd = findViewById(R.id.Ed_Command);
		final Button[] buts = {
			findViewById(R.id.but_browser),
			findViewById(R.id.but_start)
		};
		final TextView out = findViewById(R.id.output);
		
		
		sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

					if (isChecked)
					{
						isEncrypt = true;
						t.setText("Encrypt");
					}
					else
					{
						isEncrypt = false;
						t.setText("Decrypt");
					}
				}
			});

		rd[0].setChecked(true);
		cmd.setEnabled(false);
		rd[0].setOnClickListener(new RadioButton.OnClickListener() {  
				@Override  
				public void onClick(View v)
				{  
					option = 0;
					int exclude = 0;
					for (int i = 0; i < 5; i++)
					{
						if (i != exclude)
							rd[i].setChecked(false);
					}
					cmd.setEnabled(false);
				}  
			});

		rd[1].setOnClickListener(new RadioButton.OnClickListener() {  
				@Override  
				public void onClick(View v)
				{  
					option = 1;
					int exclude = 1;
					for (int i = 0; i < 5; i++)
					{
						if (i != exclude)
							rd[i].setChecked(false);
					}
					cmd.setEnabled(true);
					Toast.makeText(Encrypt.this, "Command example: jpg/pdf...", 2000).show();
				}  
			});
		rd[2].setOnClickListener(new RadioButton.OnClickListener() {  
				@Override  
				public void onClick(View v)
				{  
					option = 2;
					int exclude = 2;
					for (int i = 0; i < 5; i++)
					{
						if (i != exclude)
							rd[i].setChecked(false);
					}
					cmd.setEnabled(true);
					Toast.makeText(Encrypt.this, "Command example: jpg/pdf...", 2000).show();
				}  
			});
		rd[3].setOnClickListener(new RadioButton.OnClickListener() {  
				@Override  
				public void onClick(View v)
				{  
					option = 3;
					int exclude = 3;
					for (int i = 0; i < 5; i++)
					{
						if (i != exclude)
							rd[i].setChecked(false);
					}
					cmd.setEnabled(true);
					Toast.makeText(Encrypt.this, "Command example: a.jpg/b.pdf...", 2000).show();
				}  
			});
		rd[4].setOnClickListener(new RadioButton.OnClickListener() {  
				@Override  
				public void onClick(View v)
				{  
					option = 4;
					int exclude = 4;
					for (int i = 0; i < 5; i++)
					{
						if (i != exclude)
							rd[i].setChecked(false);
					}
					cmd.setEnabled(true);
					Toast.makeText(Encrypt.this, "Command example: a.jpg/b.pdf...", 2000).show();
				}  
			});

		buts[0].setOnClickListener(new Button.OnClickListener() {  
				@Override  
				public void onClick(View v)
				{  
					Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE); 
					i.addCategory(Intent.CATEGORY_DEFAULT);
					startActivityForResult(Intent.createChooser(i, "Choose directory"), 9999);

					Toast.makeText(Encrypt.this, "Supports internal sdcard only", 2000).show();
				}  
			});

		buts[1].setOnClickListener(new Button.OnClickListener() {  
				@Override  
				public void onClick(View v)
				{  

					buts[1].setEnabled(false);

					if (option != 0 && cmd.getText().toString().equals(""))
					{
						Toast.makeText(Encrypt.this, "Please input filter command first!", 2000).show();
						buts[1].setEnabled(true);
						return;
					}
					if (!out.getText().toString().contains("Path set:"))
					{
						Toast.makeText(Encrypt.this, "Please set directory scope first!", 2000).show();
						buts[1].setEnabled(true);
						return;
					}
					Toast.makeText(Encrypt.this, "Started, please wait", 2000).show();
					out.setText("Started. Please wait.");


					SharedPreferences shared = getSharedPreferences("pref", Encrypt.this.MODE_PRIVATE);
					String key = shared.getString("key", "");
					String homeDir = getFilesDir().toString();
					String args = String.format("%s \"%s\" %d \"%s\" %s", String.valueOf(isEncrypt), path, option, cmd.getText().toString(), key);
					String[] cmd = {"sh", "-c", String.format("cd %s && dalvikvm -cp Fire.dex Fire %s >info", homeDir, args)};
					try
					{
						Runtime.getRuntime().exec(cmd);
					}
					catch (Exception e)
					{}
				}  
			});
    }

	@Override
	public void onBackPressed()
	{
		// TODO: Implement this method
		super.onBackPressed();
		this.finish();
		Toast.makeText(this, "Operation cancelled.", 2000).show();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);

		switch (requestCode)
		{
			case 9999:
				try
				{
					String[] rawLs = URLDecoder.decode(data.getData().getEncodedPath(), "UTF-8").split(":");
					path = "/sdcard/" + (rawLs.length == 2 ?rawLs[1]: "") + "/";
					path = path.replace("//", "/");

					TextView out = findViewById(R.id.output); 
					out.setText("Path set: " + path);
				}
				catch (Exception e)
				{}break;
		}
	}
	
	//Update info realtime
	@Override
	protected void onResume()
	{
		// TODO: Implement this method
		super.onResume();

		final Handler handler = new Handler(); 
		final Runnable runnable = new Runnable() {
			public void run()
			{ 
				// need to do tasks on the UI thread 
				try
				{
					File infoFile = new File(getFilesDir().toString() + "/info");
					Scanner sc = new Scanner(infoFile);
					
					Boolean isFinished = false;
					while (sc.hasNextLine())
					{
						String line = sc.nextLine();
						TextView out = findViewById(R.id.output);
						out.setText(line);
						if(line.contains("Finished")) isFinished = true;
					}
					
					
					if(isFinished)
					{
						infoFile.delete();
						Button but = findViewById(R.id.but_start);
						but.setEnabled(true);
					}
				}
				catch (Exception e)
				{}
				handler.postDelayed(this, 100);
			} 
		}; 
		handler.post(runnable);
	}
}
