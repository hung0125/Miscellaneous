package com.iq500.protect0r;

import java.io.*;
import java.nio.file.*;
import java.util.*;

public class Fire
{
	
	//public Fire(Boolean isEncrypt, String path, int option, String command, String key)
	public static void main(String[] argv)
	{
		
		Boolean isEncrypt = Boolean.parseBoolean(argv[0]);
		String path = argv[1];//target path
		int option = Integer.parseInt(argv[2]);
		String command = argv[3];
		String key = argv[4];
		
		String[] extentions = {};
		String[] names = {};
		String[] shCmd = {"sh", "-c", ""};
		
		try
		{
			switch (option)
			{
				case 0:
					shCmd[2] = "find " + path + " -type f ";
					break;
				case 1:
				case 2:
					extentions = command.replace("/", "/.").split("/");
					extentions[0] = "." + extentions[0];
					shCmd[2] = "find " + path + " -type f ";
					break;
				case 3:
				case 4:
					names = command.split("/");
					shCmd[2] = "find " + path + " -type f ";
					break;
			}



			switch (option)
			{
				case 0:
					if (isEncrypt)
						shCmd[2] += "-not -name *.+enc";
					else
						shCmd[2] += "-name *.+enc";
					break;
				case 1:
					for (int i = 0; i < extentions.length; i++)
					{
						if (isEncrypt)
							shCmd[2] += "-name *" + extentions[i];
						else
							shCmd[2] += "-name *" + extentions[i] + ".+enc";
						if (i < extentions.length - 1)
							shCmd[2] += " -o ";
					}
					break;
				case 2:
					for (int i = 0; i < extentions.length; i++)
					{
						if (isEncrypt)
							shCmd[2] += "-not -name *" + extentions[i] + " ";
						else
							shCmd[2] += "-not -name *" + extentions[i] + ".+enc ";
					}
					break;
				case 3:
					for (int i = 0; i < names.length; i++)
					{
						if (isEncrypt)
							shCmd[2] += "-name " + names[i];
						else
							shCmd[2] += "-name " + names[i] + ".+enc";
						if (i < names.length - 1)
							shCmd[2] += " -o ";
					}
					break;
				case 4:
					for (int i = 0; i < names.length; i++)
					{
						if (isEncrypt)
							shCmd[2] += "-not -name " + names[i] + " ";
						else
							shCmd[2] += "-not -name " + names[i] + ".+enc ";
					}
					break;
			}
			shCmd[2] += " >/sdcard/file_result.txt";
			Runtime.getRuntime().exec(shCmd).waitFor();

			//print


			//Do the main jobs

			String[] keyStr = key.split(",");
			int[] intKeyStr = new int[256];
			for (int i = 0; i < 256; i++)intKeyStr[i] = Integer.parseInt(keyStr[i]);//generate key array

			File f = new File("/sdcard/file_result.txt");

			Scanner sc = new Scanner(f);
			if (isEncrypt)
			{
				while (sc.hasNextLine())
				{
					fileMod(new File(sc.nextLine()), intKeyStr, isEncrypt);
				}
			}
			else
			{
				int[] revIntKeyStr = new int[256];
				for (int i = 0; i < 256; i++)revIntKeyStr[intKeyStr[i]] = i;//swapping indices

				while (sc.hasNextLine())
				{
					fileMod(new File(sc.nextLine()), revIntKeyStr, isEncrypt);
				}
			}


			//clear
			f.delete();

		}
		catch (Exception e)
		{
			//out.setText(out.getText().toString() + "\n" + e.toString());
		}

	}

	private static void fileMod(File f, int[] intKeyStr, Boolean isEncrypt)
    {
        try
		{
            //read & modify bytes
            byte[] content = Files.readAllBytes(f.toPath());
            int[] modByte = new int[content.length];

            int cumulatePt = (int)Math.floor(content.length * 0.1);
            int startPt = 0;
            for (int i = 0; i < 10; i++)
            {
                try
				{
                    for (int j = startPt; j < startPt + 100000; j++)
                    {
                        modByte[j] = Byte.toUnsignedInt(content[j]);
                        modByte[j] = intKeyStr[modByte[j]];//original bytes -> modded bytes
                        content[j] = (byte)modByte[j];
                    }
                    startPt += cumulatePt;
                }
				catch (Exception e)
				{}

            }

            //write bytes
            try (FileOutputStream fos = new FileOutputStream(f.toPath().toString())) {
                fos.write(content);
            }

			if (isEncrypt)
			{
				f.renameTo(new File(f.getPath() + ".+enc"));
				//print
			}
			else
			{
				f.renameTo(new File(f.getPath().substring(0, f.getPath().length() - 5)));
				//print
			}

        }
		catch (Exception e)
		{System.out.println(e.toString());}
    }
}
