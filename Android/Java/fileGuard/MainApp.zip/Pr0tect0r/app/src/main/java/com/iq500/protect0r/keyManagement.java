package com.iq500.protect0r;


import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class keyManagement extends Activity {
	
	@Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		setContentView(R.layout.keymanagement);
		Toast.makeText(this, "Long click on the key to copy", Toast.LENGTH_LONG).show();
		updateKey();
		
		Button[] buttons = {
			findViewById(R.id.chKey),
			findViewById(R.id.ImportKey)
		};
		
		View.OnLongClickListener listener = new View.OnLongClickListener() {
			public boolean onLongClick(View v) {
				keyManagement.this.makeKey();
				keyManagement.this.updateKey();
				return true;
			}
		};
		buttons[0].setOnLongClickListener(listener);
		buttons[0].setOnClickListener(new Button.OnClickListener() {  
				@Override  
				public void onClick(View v)
				{  
					Toast.makeText(keyManagement.this, "Long press to continue", Toast.LENGTH_SHORT).show();
				}  
			});

		buttons[1].setOnClickListener(new Button.OnClickListener() {  
				@Override  
				public void onClick(View v)
				{  
					keyManagement.this.validate();
					keyManagement.this.updateKey();
				}  
			});
	}
	
	
    private void makeKey()
    {
        String key = "";
        ArrayList<Integer> num = new ArrayList<Integer>();
        for(int i = 0; i < 256; i++)
        {
            num.add(i);
        }
        Collections.shuffle(num);

        for(int i = 0; i < 256; i++)
        {
            key += String.valueOf(num.get(i));
            if(i < 255)
                key += ",";
        }

		SharedPreferences shared = getSharedPreferences("pref", Context.MODE_PRIVATE);
		shared.edit().putString("key", key).commit();
		Toast.makeText(this, "Created new key...", Toast.LENGTH_SHORT).show();

    }
	
	private void updateKey()
	{
	 	TextView tx = findViewById(R.id.curKey);
		SharedPreferences shared = getSharedPreferences("pref", Context.MODE_PRIVATE);
		tx.setText(shared.getString("key",""));
	}
	
	private void validate()
	{
		EditText keyInp = findViewById(R.id.ImportKeyInp);
		try
		{
			int[] answer = new int[256];
			for(int i = 0; i < 256; i++) answer[i] = i;
			
			String[] test1 = keyInp.getText().toString().replace(" ", "").split(",");
			int[] test1int = new int[256];
			for(int i = 0; i < 256; i++) test1int[i] = Integer.parseInt(test1[i]);
			Arrays.sort(test1int);
			
			
			for(int i = 0; i < 256; i++)
			{
				
				if(test1int[i] != answer[i]) throw new Exception();
			}
			
			SharedPreferences shared = getSharedPreferences("pref", Context.MODE_PRIVATE);
			shared.edit().putString("key", keyInp.getText().toString().replace(" ", "")).commit();
			Toast.makeText(this, "Import success!", Toast.LENGTH_SHORT).show();
		}catch(Exception e){
			Toast.makeText(this, "Invalid key combination, check!", Toast.LENGTH_SHORT).show();
		}
	}
}
