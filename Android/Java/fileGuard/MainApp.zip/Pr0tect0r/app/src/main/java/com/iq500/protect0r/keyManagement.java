package com.iq500.protect0r;


import android.app.*;
import android.os.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class keyManagement extends Activity {
	
	private String keyFile;
	
	
	@Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		
	}
	public keyManagement(){
		keyFile = getFilesDir().toString() + "/key.txt";
	}
    
}
